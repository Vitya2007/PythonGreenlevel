numbers = list(range(1, 11))

squared_numbers = list(map(lambda x: x ** 2, numbers))

print(squared_numbers)