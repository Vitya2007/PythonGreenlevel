first_list = [1, 3, 5, 7]
second_list = [2, 4, 6, 8]

deque = (first_list + second_list)
deque.sort()
print(deque)