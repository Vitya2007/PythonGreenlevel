matrix = [[0 for _ in range(6)] for _ in range(4)]
print(matrix)