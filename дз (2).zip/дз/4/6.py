numbers = [1, 2, 3, 4, 5]

strings_with_exclamation = [str(num) + "!" for num in numbers]

print(strings_with_exclamation)